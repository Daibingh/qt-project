## Introduction
   大家好，我是深大周杰伦，这是我大二软件工程课程的期末大作业，基于QT框架的即时聊天系统，有兴趣和我一起完善这个项目的可以联系:jay470790400@gmail.com或者470790400@qq.com
   
## V1.0(2016/5/27)
 * 注册个人账户、登录个人账号、创建群聊
 * 主界面tab选项卡（分联系人、群、消息）
 * 根据QQ号搜索添加好友及群
 * 支持在线聊天、离线消息缓存、群聊
 * 支持发送QQ表情
 * 支持拖动窗口到顶部隐藏主面板、图标闪烁效果和语音提示消息效果
 
 
![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/1.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/2.png)

登录

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/3.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/5.png)

主界面

模拟了QQ的窗口隐藏和托盘系统图标功能，包括图标闪烁效果和语音提示效果

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/6.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/8.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/11.png)

下面是一些基本的窗口展示

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/7.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/9.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/10.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/12.png)

![](https://raw.githubusercontent.com/Blackmamba-xuan/QQ/master/Screenshot/13.png)

更多信息请用Qt creator打开查看




